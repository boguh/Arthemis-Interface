/*
 * stp16cp05.h
 *
 *  Created on: 17 janv. 2018
 *  Author: Nirgal
 *
 *      Le driver de LED STP16C05 pilote jusqu'� 16 LED en fournissant un courant r�gul� commun et r�glable (via une r�sistance de r�f�rence).
 *
 */

#ifndef STP16CP05_H_
#define STP16CP05_H_
#include <stdint.h>

void STP16CP05_init(void);
void STP16CP05_test(void);
void STP16CP05_set_leds(uint16_t leds);


#endif /* STP16CP05_H_ */
